# Proyecto ejemplo para la materia:
## Sistemas de Información.

![FES Aragón](https://amei.mx/wp-content/uploads/2016/08/UNAM-FES-Aragon-276x300.png)

### Aviso:
El presente proyecto no debe ser considerado un sistema completo, la hacen falta
lógica de aplicación y los elementos de seguridad no están completos.

Fecha   |   Descripción
------- |   -----------
10/02/21 |  Sesiones
